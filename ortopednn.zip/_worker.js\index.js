globalThis.process ??= {}; globalThis.process.env ??= {};
import { renderers } from './renderers.mjs';
import { c as createExports, s as serverEntrypointModule } from './chunks/_@astrojs-ssr-adapter_CNTtSDZy.mjs';
import { manifest } from './manifest_Rxi6NmDM.mjs';

const serverIslandMap = new Map();;

const _page0 = () => import('./pages/_image.astro.mjs');
const _page1 = () => import('./pages/404.astro.mjs');
const _page2 = () => import('./pages/about.astro.mjs');
const _page3 = () => import('./pages/admin/_---catchall_.astro.mjs');
const _page4 = () => import('./pages/blog/care-crown.astro.mjs');
const _page5 = () => import('./pages/blog/care-denture.astro.mjs');
const _page6 = () => import('./pages/blog/first-visit.astro.mjs');
const _page7 = () => import('./pages/blog.astro.mjs');
const _page8 = () => import('./pages/checkup.astro.mjs');
const _page9 = () => import('./pages/compare.astro.mjs');
const _page10 = () => import('./pages/materials.astro.mjs');
const _page11 = () => import('./pages/services/armirovanie.astro.mjs');
const _page12 = () => import('./pages/services/byugelnaya-koronka.astro.mjs');
const _page13 = () => import('./pages/services/byugelnyj.astro.mjs');
const _page14 = () => import('./pages/services/byugelnyj-zamki.astro.mjs');
const _page15 = () => import('./pages/services/celnolitaya-koronka.astro.mjs');
const _page16 = () => import('./pages/services/celnolitaya-koronka-na-vkladke.astro.mjs');
const _page17 = () => import('./pages/services/celnolitaya-koronka-ni-cr.astro.mjs');
const _page18 = () => import('./pages/services/cirkonievaya-koronka.astro.mjs');
const _page19 = () => import('./pages/services/czirkon-titan-mzp.astro.mjs');
const _page20 = () => import('./pages/services/diagnosticheskaya-model.astro.mjs');
const _page21 = () => import('./pages/services/dopolnitelnyj-zamok.astro.mjs');
const _page22 = () => import('./pages/services/esteticheskij-prototip.astro.mjs');
const _page23 = () => import('./pages/services/fiksaciya-fuji.astro.mjs');
const _page24 = () => import('./pages/services/fiksaciya-maxcem.astro.mjs');
const _page25 = () => import('./pages/services/fiksaciya-temp-bond.astro.mjs');
const _page26 = () => import('./pages/services/iskusstvennaya-desna.astro.mjs');
const _page27 = () => import('./pages/services/kljammer-dopolnitelnyj.astro.mjs');
const _page28 = () => import('./pages/services/korrekciya.astro.mjs');
const _page29 = () => import('./pages/services/korrekciya-semnogo.astro.mjs');
const _page30 = () => import('./pages/services/laboratornaya-vkladka.astro.mjs');
const _page31 = () => import('./pages/services/lozhka-individualnaya.astro.mjs');
const _page32 = () => import('./pages/services/metallokeramicheskaya-koronka-na-vkladke.astro.mjs');
const _page33 = () => import('./pages/services/metallokeramika.astro.mjs');
const _page34 = () => import('./pages/services/metalloplastmassovaya-koronka.astro.mjs');
const _page35 = () => import('./pages/services/model-3d-print.astro.mjs');
const _page36 = () => import('./pages/services/modelirovanie-voskom.astro.mjs');
const _page37 = () => import('./pages/services/otlisk-alginatnyj.astro.mjs');
const _page38 = () => import('./pages/services/otlisk-elite.astro.mjs');
const _page39 = () => import('./pages/services/otlisk-impregum.astro.mjs');
const _page40 = () => import('./pages/services/otlisk-speedex.astro.mjs');
const _page41 = () => import('./pages/services/perebazirovka-implakril.astro.mjs');
const _page42 = () => import('./pages/services/perebazirovka-laboratornaya.astro.mjs');
const _page43 = () => import('./pages/services/perebazirovka-vrachebnaya.astro.mjs');
const _page44 = () => import('./pages/services/poychinika-semnogo.astro.mjs');
const _page45 = () => import('./pages/services/prikusnoj-shablon.astro.mjs');
const _page46 = () => import('./pages/services/prikusnoj-shablon-bazis.astro.mjs');
const _page47 = () => import('./pages/services/privarka-1-zuba.astro.mjs');
const _page48 = () => import('./pages/services/privarka-2-zubov.astro.mjs');
const _page49 = () => import('./pages/services/privarka-3-zubov.astro.mjs');
const _page50 = () => import('./pages/services/prochie-raboty.astro.mjs');
const _page51 = () => import('./pages/services/prototype.astro.mjs');
const _page52 = () => import('./pages/services/razbornaya-celnolitaya-koronka.astro.mjs');
const _page53 = () => import('./pages/services/razbornaya-vkladka.astro.mjs');
const _page54 = () => import('./pages/services/silikonovyj-klyuch.astro.mjs');
const _page55 = () => import('./pages/services/sjemny-protez.astro.mjs');
const _page56 = () => import('./pages/services/snatie-celnolicyh.astro.mjs');
const _page57 = () => import('./pages/services/snatie-shtampovannyh.astro.mjs');
const _page58 = () => import('./pages/services/vinir-na-refraktore.astro.mjs');
const _page59 = () => import('./pages/services/viniry-emaks.astro.mjs');
const _page60 = () => import('./pages/services/vkladka.astro.mjs');
const _page61 = () => import('./pages/services/vrachebnaya-vkladka.astro.mjs');
const _page62 = () => import('./pages/services/vremennaya-koronka.astro.mjs');
const _page63 = () => import('./pages/services/vremennaya-koronka-lab.astro.mjs');
const _page64 = () => import('./pages/services.astro.mjs');
const _page65 = () => import('./pages/index.astro.mjs');
const pageMap = new Map([
    ["node_modules/astro/dist/assets/endpoint/generic.js", _page0],
    ["src/pages/404.astro", _page1],
    ["src/pages/about.astro", _page2],
    ["src/pages/admin/[...catchall].astro", _page3],
    ["src/pages/blog/care-crown.astro", _page4],
    ["src/pages/blog/care-denture.astro", _page5],
    ["src/pages/blog/first-visit.astro", _page6],
    ["src/pages/blog/index.astro", _page7],
    ["src/pages/checkup/index.astro", _page8],
    ["src/pages/compare/index.astro", _page9],
    ["src/pages/materials/index.astro", _page10],
    ["src/pages/services/armirovanie.astro", _page11],
    ["src/pages/services/byugelnaya-koronka.astro", _page12],
    ["src/pages/services/byugelnyj.astro", _page13],
    ["src/pages/services/byugelnyj-zamki.astro", _page14],
    ["src/pages/services/celnolitaya-koronka.astro", _page15],
    ["src/pages/services/celnolitaya-koronka-na-vkladke.astro", _page16],
    ["src/pages/services/celnolitaya-koronka-ni-cr.astro", _page17],
    ["src/pages/services/cirkonievaya-koronka.astro", _page18],
    ["src/pages/services/czirkon-titan-mzp.astro", _page19],
    ["src/pages/services/diagnosticheskaya-model.astro", _page20],
    ["src/pages/services/dopolnitelnyj-zamok.astro", _page21],
    ["src/pages/services/esteticheskij-prototip.astro", _page22],
    ["src/pages/services/fiksaciya-fuji.astro", _page23],
    ["src/pages/services/fiksaciya-maxcem.astro", _page24],
    ["src/pages/services/fiksaciya-temp-bond.astro", _page25],
    ["src/pages/services/iskusstvennaya-desna.astro", _page26],
    ["src/pages/services/kljammer-dopolnitelnyj.astro", _page27],
    ["src/pages/services/korrekciya.astro", _page28],
    ["src/pages/services/korrekciya-semnogo.astro", _page29],
    ["src/pages/services/laboratornaya-vkladka.astro", _page30],
    ["src/pages/services/lozhka-individualnaya.astro", _page31],
    ["src/pages/services/metallokeramicheskaya-koronka-na-vkladke.astro", _page32],
    ["src/pages/services/metallokeramika.astro", _page33],
    ["src/pages/services/metalloplastmassovaya-koronka.astro", _page34],
    ["src/pages/services/model-3d-print.astro", _page35],
    ["src/pages/services/modelirovanie-voskom.astro", _page36],
    ["src/pages/services/otlisk-alginatnyj.astro", _page37],
    ["src/pages/services/otlisk-elite.astro", _page38],
    ["src/pages/services/otlisk-impregum.astro", _page39],
    ["src/pages/services/otlisk-speedex.astro", _page40],
    ["src/pages/services/perebazirovka-implakril.astro", _page41],
    ["src/pages/services/perebazirovka-laboratornaya.astro", _page42],
    ["src/pages/services/perebazirovka-vrachebnaya.astro", _page43],
    ["src/pages/services/poychinika-semnogo.astro", _page44],
    ["src/pages/services/prikusnoj-shablon.astro", _page45],
    ["src/pages/services/prikusnoj-shablon-bazis.astro", _page46],
    ["src/pages/services/privarka-1-zuba.astro", _page47],
    ["src/pages/services/privarka-2-zubov.astro", _page48],
    ["src/pages/services/privarka-3-zubov.astro", _page49],
    ["src/pages/services/prochie-raboty.astro", _page50],
    ["src/pages/services/prototype.astro", _page51],
    ["src/pages/services/razbornaya-celnolitaya-koronka.astro", _page52],
    ["src/pages/services/razbornaya-vkladka.astro", _page53],
    ["src/pages/services/silikonovyj-klyuch.astro", _page54],
    ["src/pages/services/sjemny-protez.astro", _page55],
    ["src/pages/services/snatie-celnolicyh.astro", _page56],
    ["src/pages/services/snatie-shtampovannyh.astro", _page57],
    ["src/pages/services/vinir-na-refraktore.astro", _page58],
    ["src/pages/services/viniry-emaks.astro", _page59],
    ["src/pages/services/vkladka.astro", _page60],
    ["src/pages/services/vrachebnaya-vkladka.astro", _page61],
    ["src/pages/services/vremennaya-koronka.astro", _page62],
    ["src/pages/services/vremennaya-koronka-lab.astro", _page63],
    ["src/pages/services/index.astro", _page64],
    ["src/pages/index.astro", _page65]
]);

const _manifest = Object.assign(manifest, {
    pageMap,
    serverIslandMap,
    renderers,
    actions: () => import('./noop-entrypoint.mjs'),
    middleware: () => import('./_astro-internal_middleware.mjs')
});
const _args = undefined;
const _exports = createExports(_manifest);
const __astrojsSsrVirtualEntry = _exports.default;
const _start = 'start';
if (Object.prototype.hasOwnProperty.call(serverEntrypointModule, _start)) {
	serverEntrypointModule[_start](_manifest, _args);
}

export { __astrojsSsrVirtualEntry as default, pageMap };
