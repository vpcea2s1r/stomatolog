globalThis.process ??= {}; globalThis.process.env ??= {};
import { f as createComponent, l as renderHead, r as renderTemplate } from '../../chunks/astro/server_CFrqtsOb.mjs';
export { renderers } from '../../renderers.mjs';

const prerender = false;
const $$ = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`<html> <head><meta charset="utf-8"><meta name="robots" content="noindex"><title>Admin | Ортопед НН</title>${renderHead()}</head> <body> <h1>Keystatic Admin</h1> <p>Для редактирования используйте Keystatic CMS.</p> <p>Настройте GitHub OAuth в Cloudflare Pages для доступа к админке.</p> </body></html>`;
}, "C:/opencode/ortopednn-auto/src/pages/admin/[...catchall].astro", void 0);

const $$file = "C:/opencode/ortopednn-auto/src/pages/admin/[...catchall].astro";
const $$url = "/admin/[...catchall]";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$,
  file: $$file,
  prerender,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
